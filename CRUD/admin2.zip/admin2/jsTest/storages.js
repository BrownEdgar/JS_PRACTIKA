import { MAIN_ARRAY_NAME } from "./constants.js";

class Storage {

	
}

export default Storage;