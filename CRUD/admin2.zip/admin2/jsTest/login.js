import Storage from './storages.js'

const auth = {
	username: "admin",
	password: "admin"
}